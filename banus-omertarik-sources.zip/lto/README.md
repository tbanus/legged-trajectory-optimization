# legged-trajectory-optimization
to build and run 

    cmake ..
    make -j8
    ./lto

you have to have ifopt, python3, matplotlib, eigen3, ipopt installed. there may be other dependencies. i used gcc on linux.